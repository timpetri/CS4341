# CS4341


### Work Split:
	Nicolas Bradford:	astar.py, structure
	Thomas Grimshaw:	test boards, analysis
	Lucas Lebrao:		heuristic.py
	Tim Petri:			state.py

### Usage:
	python astar.py {input_file.txt} {heuristic 1-6}

### Coordinate System:
	The world is noted in (y, x) starting from the top left, as is customary with matrices.